export { default } from './CookieBanner';

