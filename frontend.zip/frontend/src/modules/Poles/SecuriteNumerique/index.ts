export { default } from './SecuriteNumerique';

