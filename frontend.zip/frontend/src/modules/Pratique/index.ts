export { default as FormationContinue } from './FormationContinue';
export { default as Deontologie } from './Deontologie';
export { default as Pharmacies } from './Pharmacies';
export { default as ContactPratique } from './ContactPratique';

