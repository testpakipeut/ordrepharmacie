import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';

// Types pour les photos
interface Photo {
  id: string;
  title: string;
  description: string;
  image: string;
  album: string;
  date: string;
  tags: string[];
  photographer?: string;
  location?: string;
  downloads: number;
  likes: number;
  featured: boolean;
}

interface Album {
  id: string;
  name: string;
  description: string;
  coverImage: string;
  photoCount: number;
  featured: boolean;
}

// Données fictives d'albums
const mockAlbums: Album[] = [
  {
    id: 'congres-2024',
    name: 'Congrès National 2024',
    description: 'Photos du 15ème Congrès National des Pharmaciens du Gabon',
    coverImage: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&h=300&fit=crop',
    photoCount: 45,
    featured: true
  },
  {
    id: 'formations',
    name: 'Sessions de Formation',
    description: 'Moments capturés lors des formations continues',
    coverImage: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=400&h=300&fit=crop',
    photoCount: 28,
    featured: false
  },
  {
    id: 'officines',
    name: 'Visites d\'Officines',
    description: 'Découverte des pharmacies modernes du Gabon',
    coverImage: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=300&fit=crop',
    photoCount: 32,
    featured: false
  },
  {
    id: 'evenements',
    name: 'Événements Spéciaux',
    description: 'Cérémonies, remises de prix et moments importants',
    coverImage: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=400&h=300&fit=crop',
    photoCount: 67,
    featured: true
  }
];

// Données fictives de photos
const mockPhotos: Photo[] = [
  {
    id: '1',
    title: 'Ouverture du Congrès',
    description: 'Cérémonie d\'ouverture du 15ème Congrès National des Pharmaciens',
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=600&fit=crop',
    album: 'congres-2024',
    date: '2024-01-15',
    tags: ['congrès', 'ouverture', 'cérémonie'],
    photographer: 'Jean Dupont',
    location: 'Palais des Congrès, Libreville',
    downloads: 245,
    likes: 89,
    featured: true
  },
  {
    id: '2',
    title: 'Atelier Formation Continue',
    description: 'Session pratique sur les nouvelles technologies en pharmacie',
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=600&fit=crop',
    album: 'formations',
    date: '2024-01-12',
    tags: ['formation', 'technologie', 'atelier'],
    photographer: 'Marie Leroy',
    location: 'Centre de Formation ONPG',
    downloads: 156,
    likes: 67,
    featured: false
  },
  {
    id: '3',
    title: 'Officine Moderne',
    description: 'Espace de dispensation moderne avec technologies avancées',
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=800&h=600&fit=crop',
    album: 'officines',
    date: '2024-01-10',
    tags: ['officine', 'moderne', 'technologie'],
    photographer: 'Pierre Martin',
    location: 'Pharmacie Centrale, Libreville',
    downloads: 198,
    likes: 134,
    featured: true
  },
  {
    id: '4',
    title: 'Remise des Diplômes',
    description: 'Cérémonie de remise des diplômes aux nouveaux pharmaciens',
    image: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=800&h=600&fit=crop',
    album: 'evenements',
    date: '2024-01-08',
    tags: ['diplômes', 'cérémonie', 'remise'],
    photographer: 'Sophie Bernard',
    location: 'Université des Sciences de la Santé',
    downloads: 312,
    likes: 201,
    featured: false
  }
];

const Photos = () => {
  const [photos, setPhotos] = useState<Photo[]>(mockPhotos);
  const [albums, setAlbums] = useState<Album[]>(mockAlbums);
  const [filteredPhotos, setFilteredPhotos] = useState<Photo[]>(mockPhotos);
  const [selectedAlbum, setSelectedAlbum] = useState('Tous');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'albums' | 'photos'>('albums');
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  const photosPerPage = 12;

  // Filtrage des photos
  useEffect(() => {
    let filtered = photos.filter(photo => {
      const matchesSearch = photo.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           photo.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           photo.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesAlbum = selectedAlbum === 'Tous' || photo.album === selectedAlbum;
      return matchesSearch && matchesAlbum;
    });

    setFilteredPhotos(filtered);
    setCurrentPage(1);
  }, [photos, searchQuery, selectedAlbum]);

  // Pagination
  const totalPages = Math.ceil(filteredPhotos.length / photosPerPage);
  const startIndex = (currentPage - 1) * photosPerPage;
  const endIndex = startIndex + photosPerPage;
  const currentPhotos = filteredPhotos.slice(startIndex, endIndex);

  // Statistiques
  const stats = useMemo(() => ({
    totalPhotos: photos.length,
    totalAlbums: albums.length,
    totalDownloads: photos.reduce((sum, photo) => sum + photo.downloads, 0),
    featuredPhotos: photos.filter(photo => photo.featured).length
  }), [photos, albums]);

  const openLightbox = (photo: Photo) => {
    setSelectedPhoto(photo);
    setLightboxOpen(true);
  };

  const closeLightbox = () => {
    setLightboxOpen(false);
    setSelectedPhoto(null);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedAlbum('Tous');
    setCurrentPage(1);
  };

  return (
    <div className="ressources-page">
      {/* Hero Section */}
      <section className="ressources-hero">
        <div className="hero-content">
          <div className="hero-text">
            <h1 className="hero-title">
              <span className="hero-title-main">Galerie</span>
              <span className="hero-title-subtitle">Photo</span>
            </h1>
            <p className="hero-description">
              Découvrez l'univers de la pharmacie gabonaise à travers nos albums photos.
              Moments importants, événements marquants et coulisses de la profession.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="hero-stats">
            <div className="stat-card">
              <div className="stat-number">{stats.totalPhotos}</div>
              <div className="stat-label">Photos</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{stats.totalAlbums}</div>
              <div className="stat-label">Albums</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{stats.totalDownloads.toLocaleString()}</div>
              <div className="stat-label">Téléchargements</div>
            </div>
          </div>
        </div>

        {/* Background Pattern */}
        <div className="hero-bg-pattern">
          <div className="pattern-shape shape-1"></div>
          <div className="pattern-shape shape-2"></div>
          <div className="pattern-shape shape-3"></div>
        </div>
      </section>

      {/* Main Content */}
      <div className="ressources-container">
        {/* Sidebar */}
        <aside className="ressources-sidebar">
          <div className="sidebar-section">
            <h3 className="sidebar-title">Navigation</h3>
            <div className="view-toggle">
              <button
                className={`toggle-btn ${viewMode === 'albums' ? 'active' : ''}`}
                onClick={() => setViewMode('albums')}
              >
                📁 Albums
              </button>
              <button
                className={`toggle-btn ${viewMode === 'photos' ? 'active' : ''}`}
                onClick={() => setViewMode('photos')}
              >
                📸 Photos
              </button>
            </div>
          </div>

          <div className="sidebar-section">
            <h3 className="sidebar-title">Rechercher</h3>
            <form onSubmit={handleSearch} className="search-form">
              <div className="search-input-wrapper">
                <input
                  type="text"
                  placeholder="Rechercher une photo..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                />
                <button type="submit" className="search-button">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
              </div>
            </form>
          </div>

          {viewMode === 'photos' && (
            <div className="sidebar-section">
              <h3 className="sidebar-title">Albums</h3>
              <div className="category-filters">
                <button
                  className={`category-filter ${selectedAlbum === 'Tous' ? 'active' : ''}`}
                  onClick={() => setSelectedAlbum('Tous')}
                >
                  Tous les albums
                </button>
                {albums.map(album => (
                  <button
                    key={album.id}
                    className={`category-filter ${selectedAlbum === album.id ? 'active' : ''}`}
                    onClick={() => setSelectedAlbum(album.id)}
                  >
                    {album.name}
                    <span className="category-count">({album.photoCount})</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="sidebar-section">
            <button onClick={clearFilters} className="clear-filters-btn">
              🗑️ Effacer les filtres
            </button>
          </div>

          {/* Stats de la galerie */}
          <div className="sidebar-section">
            <h3 className="sidebar-title">Statistiques</h3>
            <div className="gallery-stats">
              <div className="stat-item">
                <span className="stat-value">{stats.featuredPhotos}</span>
                <span className="stat-label">À la une</span>
              </div>
              <div className="stat-item">
                <span className="stat-value">{photos.filter(p => p.likes > 100).length}</span>
                <span className="stat-label">Populaires</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="ressources-main">
          <nav className="breadcrumb">
            <Link to="/">Accueil</Link>
            <span className="breadcrumb-separator">›</span>
            <Link to="/ressources">Ressources</Link>
            <span className="breadcrumb-separator">›</span>
            <span className="breadcrumb-current">Photos</span>
          </nav>

          {viewMode === 'albums' ? (
            /* Vue Albums */
            <div className="albums-view">
              <div className="albums-grid">
                {albums.map(album => (
                  <div key={album.id} className={`album-card ${album.featured ? 'featured' : ''}`}>
                    <div className="album-image">
                      <img src={album.coverImage} alt={album.name} />
                      {album.featured && (
                        <div className="featured-badge">⭐ À la une</div>
                      )}
                      <div className="album-overlay">
                        <div className="album-info">
                          <h3>{album.name}</h3>
                          <p>{album.description}</p>
                          <span className="photo-count">{album.photoCount} photos</span>
                        </div>
                        <button
                          className="view-album-btn"
                          onClick={() => {
                            setSelectedAlbum(album.id);
                            setViewMode('photos');
                          }}
                        >
                          Voir l'album →
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Vue Photos */
            <div className="photos-view">
              <div className="results-header">
                <h2 className="results-title">
                  {filteredPhotos.length} photo{filteredPhotos.length > 1 ? 's' : ''}
                  {searchQuery && ` pour "${searchQuery}"`}
                  {selectedAlbum !== 'Tous' && ` dans ${albums.find(a => a.id === selectedAlbum)?.name}`}
                </h2>
                <div className="results-meta">
                  Page {currentPage} sur {totalPages}
                </div>
              </div>

              <div className="photos-grid">
                {currentPhotos.map(photo => (
                  <div
                    key={photo.id}
                    className={`photo-card ${photo.featured ? 'featured' : ''}`}
                    onClick={() => openLightbox(photo)}
                  >
                    <div className="photo-image">
                      <img src={photo.image} alt={photo.title} />
                      {photo.featured && (
                        <div className="featured-badge">⭐</div>
                      )}
                      <div className="photo-overlay">
                        <div className="photo-actions">
                          <button className="photo-action-btn">
                            ❤️ {photo.likes}
                          </button>
                          <button className="photo-action-btn">
                            ⬇️ {photo.downloads}
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="photo-info">
                      <h3 className="photo-title">{photo.title}</h3>
                      <p className="photo-description">{photo.description}</p>
                      <div className="photo-meta">
                        <span className="photo-date">📅 {new Date(photo.date).toLocaleDateString('fr-FR')}</span>
                        {photo.location && <span className="photo-location">📍 {photo.location}</span>}
                      </div>
                      <div className="photo-tags">
                        {photo.tags.slice(0, 2).map(tag => (
                          <span key={tag} className="photo-tag">#{tag}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="pagination">
                  <button
                    className="pagination-btn"
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                  >
                    ← Précédent
                  </button>

                  <div className="pagination-numbers">
                    {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                      <button
                        key={page}
                        className={`pagination-number ${currentPage === page ? 'active' : ''}`}
                        onClick={() => setCurrentPage(page)}
                      >
                        {page}
                      </button>
                    ))}
                  </div>

                  <button
                    className="pagination-btn"
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                  >
                    Suivant →
                  </button>
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      {/* Lightbox */}
      {lightboxOpen && selectedPhoto && (
        <div className="lightbox-overlay" onClick={closeLightbox}>
          <div className="lightbox-content" onClick={e => e.stopPropagation()}>
            <button className="lightbox-close" onClick={closeLightbox}>✕</button>

            <div className="lightbox-image">
              <img src={selectedPhoto.image} alt={selectedPhoto.title} />
            </div>

            <div className="lightbox-info">
              <h2>{selectedPhoto.title}</h2>
              <p className="lightbox-description">{selectedPhoto.description}</p>

              <div className="lightbox-meta">
                <div className="meta-item">
                  <span className="meta-label">📅 Date:</span>
                  <span className="meta-value">{new Date(selectedPhoto.date).toLocaleDateString('fr-FR')}</span>
                </div>
                {selectedPhoto.photographer && (
                  <div className="meta-item">
                    <span className="meta-label">📸 Photographe:</span>
                    <span className="meta-value">{selectedPhoto.photographer}</span>
                  </div>
                )}
                {selectedPhoto.location && (
                  <div className="meta-item">
                    <span className="meta-label">📍 Lieu:</span>
                    <span className="meta-value">{selectedPhoto.location}</span>
                  </div>
                )}
              </div>

              <div className="lightbox-stats">
                <span className="stat-item">❤️ {selectedPhoto.likes} J'aime</span>
                <span className="stat-item">⬇️ {selectedPhoto.downloads} Téléchargements</span>
              </div>

              <div className="lightbox-tags">
                {selectedPhoto.tags.map(tag => (
                  <span key={tag} className="lightbox-tag">#{tag}</span>
                ))}
              </div>

              <div className="lightbox-actions">
                <button className="lightbox-action-btn primary">
                  ⬇️ Télécharger
                </button>
                <button className="lightbox-action-btn secondary">
                  ❤️ J'aime
                </button>
                <button className="lightbox-action-btn secondary">
                  🔗 Partager
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Photos;

