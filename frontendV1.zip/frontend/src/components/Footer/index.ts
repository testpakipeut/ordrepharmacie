export { default } from './Footer';

