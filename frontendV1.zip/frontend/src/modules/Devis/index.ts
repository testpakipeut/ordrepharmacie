export { default } from './Devis';

