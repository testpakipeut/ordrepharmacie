export { default as MentionsLegales } from './MentionsLegales';
export { default as PolitiqueConfidentialite } from './PolitiqueConfidentialite';
export { default as CGU } from './CGU';

