import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import './Ressources.css';

// Types pour les données fictives
interface Article {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  image: string;
  tags: string[];
  readTime: number;
  featured: boolean;
  views: number;
}

// Données fictives d'actualités
const mockArticles: Article[] = [
  {
    id: '1',
    title: 'Nouveau décret sur la dispensation des médicaments',
    excerpt: 'Le ministre de la Santé annonce de nouvelles mesures concernant la dispensation des médicaments en officine.',
    content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    author: 'Dr. Marie Dupont',
    date: '2024-01-15',
    category: 'Réglementation',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&h=400&fit=crop',
    tags: ['décret', 'dispensation', 'médicaments'],
    readTime: 5,
    featured: true,
    views: 2450
  },
  {
    id: '2',
    title: 'Formation continue : Nouvelles obligations pour 2024',
    excerpt: 'Découvrez les nouvelles exigences en matière de formation continue pour les pharmaciens.',
    content: 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
    author: 'Pr. Jean Martin',
    date: '2024-01-12',
    category: 'Formation',
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=400&fit=crop',
    tags: ['formation', 'obligation', '2024'],
    readTime: 7,
    featured: false,
    views: 1890
  },
  {
    id: '3',
    title: 'Étude : Impact des génériques sur les dépenses de santé',
    excerpt: 'Une nouvelle étude révèle l\'impact positif des médicaments génériques sur les dépenses de santé publique.',
    content: 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
    author: 'Dr. Sophie Bernard',
    date: '2024-01-10',
    category: 'Études',
    image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=800&h=400&fit=crop',
    tags: ['génériques', 'dépenses', 'étude'],
    readTime: 8,
    featured: true,
    views: 3200
  },
  {
    id: '4',
    title: 'Sécurité médicamenteuse : Nouveaux protocoles',
    excerpt: 'L\'ONPG présente les nouveaux protocoles de sécurité médicamenteuse pour les officines.',
    content: 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    author: 'Dr. Pierre Dubois',
    date: '2024-01-08',
    category: 'Sécurité',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=800&h=400&fit=crop',
    tags: ['sécurité', 'protocoles', 'officines'],
    readTime: 6,
    featured: false,
    views: 1560
  },
  {
    id: '5',
    title: 'Prix des médicaments : Négociations en cours',
    excerpt: 'Les négociations entre l\'ONPG et les laboratoires pharmaceutiques se poursuivent.',
    content: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium.',
    author: 'Mme Claire Leroy',
    date: '2024-01-05',
    category: 'Économie',
    image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=800&h=400&fit=crop',
    tags: ['prix', 'négociations', 'laboratoires'],
    readTime: 4,
    featured: false,
    views: 2100
  }
];

const categories = ['Toutes', 'Réglementation', 'Formation', 'Études', 'Sécurité', 'Économie'];

const RessourcesActualites = () => {
  const [articles, setArticles] = useState<Article[]>(mockArticles);
  const [filteredArticles, setFilteredArticles] = useState<Article[]>(mockArticles);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Toutes');
  const [sortBy, setSortBy] = useState<'date' | 'views' | 'title'>('date');
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(false);

  const articlesPerPage = 6;

  // Filtrage et tri des articles
  useEffect(() => {
    let filtered = articles.filter(article => {
      const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesCategory = selectedCategory === 'Toutes' || article.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });

    // Tri
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'date':
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case 'views':
          return b.views - a.views;
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

    setFilteredArticles(filtered);
    setCurrentPage(1);
  }, [articles, searchQuery, selectedCategory, sortBy]);

  // Pagination
  const totalPages = Math.ceil(filteredArticles.length / articlesPerPage);
  const startIndex = (currentPage - 1) * articlesPerPage;
  const endIndex = startIndex + articlesPerPage;
  const currentArticles = filteredArticles.slice(startIndex, endIndex);

  // Statistiques
  const stats = useMemo(() => ({
    totalArticles: articles.length,
    totalViews: articles.reduce((sum, article) => sum + article.views, 0),
    featuredArticles: articles.filter(article => article.featured).length,
    categoriesCount: categories.length - 1 // -1 pour "Toutes"
  }), [articles]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // La recherche se fait automatiquement via useEffect
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('Toutes');
    setSortBy('date');
    setCurrentPage(1);
  };

  return (
    <div className="ressources-page">
      {/* Hero Section */}
      <section className="ressources-hero">
        <div className="hero-content">
          <div className="hero-text">
            <h1 className="hero-title">
              <span className="hero-title-main">Actualités</span>
              <span className="hero-title-subtitle">Pharmaceutiques</span>
            </h1>
            <p className="hero-description">
              Restez informé des dernières actualités du monde pharmaceutique gabonais.
              Réglementation, formation, études et bien plus encore.
            </p>
          </div>

          {/* Stats Cards */}
          <div className="hero-stats">
            <div className="stat-card">
              <div className="stat-number">{stats.totalArticles}</div>
              <div className="stat-label">Articles</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{stats.totalViews.toLocaleString()}</div>
              <div className="stat-label">Vues totales</div>
            </div>
            <div className="stat-card">
              <div className="stat-number">{stats.categoriesCount}</div>
              <div className="stat-label">Catégories</div>
            </div>
          </div>
        </div>

        {/* Background Pattern */}
        <div className="hero-bg-pattern">
          <div className="pattern-shape shape-1"></div>
          <div className="pattern-shape shape-2"></div>
          <div className="pattern-shape shape-3"></div>
        </div>
      </section>

      {/* Main Content */}
      <div className="ressources-container">
        {/* Sidebar avec filtres */}
        <aside className="ressources-sidebar">
          <div className="sidebar-section">
            <h3 className="sidebar-title">Rechercher</h3>
            <form onSubmit={handleSearch} className="search-form">
              <div className="search-input-wrapper">
                <input
                  type="text"
                  placeholder="Rechercher un article..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                />
                <button type="submit" className="search-button">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M21 21L15 15M17 10C17 13.866 13.866 17 10 17C6.13401 17 3 13.866 3 10C3 6.13401 6.13401 3 10 3C13.866 3 17 6.13401 17 10Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
              </div>
            </form>
          </div>

          <div className="sidebar-section">
            <h3 className="sidebar-title">Catégories</h3>
            <div className="category-filters">
              {categories.map(category => (
                <button
                  key={category}
                  className={`category-filter ${selectedCategory === category ? 'active' : ''}`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                  {category !== 'Toutes' && (
                    <span className="category-count">
                      ({articles.filter(a => a.category === category).length})
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          <div className="sidebar-section">
            <h3 className="sidebar-title">Trier par</h3>
            <div className="sort-options">
              <button
                className={`sort-option ${sortBy === 'date' ? 'active' : ''}`}
                onClick={() => setSortBy('date')}
              >
                📅 Plus récent
              </button>
              <button
                className={`sort-option ${sortBy === 'views' ? 'active' : ''}`}
                onClick={() => setSortBy('views')}
              >
                👁️ Plus populaire
              </button>
              <button
                className={`sort-option ${sortBy === 'title' ? 'active' : ''}`}
                onClick={() => setSortBy('title')}
              >
                📝 Alphabétique
              </button>
            </div>
          </div>

          <div className="sidebar-section">
            <button onClick={clearFilters} className="clear-filters-btn">
              🗑️ Effacer les filtres
            </button>
          </div>

          {/* Articles populaires */}
          <div className="sidebar-section">
            <h3 className="sidebar-title">Articles populaires</h3>
            <div className="popular-articles">
              {articles
                .sort((a, b) => b.views - a.views)
                .slice(0, 3)
                .map(article => (
                  <Link
                    key={article.id}
                    to={`/actualites/${article.id}`}
                    className="popular-article-item"
                  >
                    <div className="popular-article-image">
                      <img src={article.image} alt={article.title} />
                    </div>
                    <div className="popular-article-content">
                      <h4>{article.title.substring(0, 50)}...</h4>
                      <span className="popular-article-views">👁️ {article.views}</span>
                    </div>
                  </Link>
                ))}
            </div>
          </div>
        </aside>

        {/* Main content */}
        <main className="ressources-main">
          {/* Breadcrumb */}
          <nav className="breadcrumb">
            <Link to="/">Accueil</Link>
            <span className="breadcrumb-separator">›</span>
            <Link to="/ressources">Ressources</Link>
            <span className="breadcrumb-separator">›</span>
            <span className="breadcrumb-current">Actualités</span>
          </nav>

          {/* Results header */}
          <div className="results-header">
            <h2 className="results-title">
              {filteredArticles.length} article{filteredArticles.length > 1 ? 's' : ''} trouvé{filteredArticles.length > 1 ? 's' : ''}
              {searchQuery && ` pour "${searchQuery}"`}
              {selectedCategory !== 'Toutes' && ` dans ${selectedCategory}`}
            </h2>
            <div className="results-meta">
              Page {currentPage} sur {totalPages}
            </div>
          </div>

          {/* Articles grid */}
          <div className="articles-grid">
            {currentArticles.map(article => (
              <article key={article.id} className={`article-card ${article.featured ? 'featured' : ''}`}>
                <div className="article-image">
                  <img src={article.image} alt={article.title} />
                  {article.featured && (
                    <div className="featured-badge">⭐ À la une</div>
                  )}
                  <div className="article-category">{article.category}</div>
                </div>

                <div className="article-content">
                  <div className="article-meta">
                    <span className="article-author">👤 {article.author}</span>
                    <span className="article-date">📅 {new Date(article.date).toLocaleDateString('fr-FR')}</span>
                    <span className="article-readtime">⏱️ {article.readTime} min</span>
                  </div>

                  <h3 className="article-title">
                    <Link to={`/actualites/${article.id}`}>{article.title}</Link>
                  </h3>

                  <p className="article-excerpt">{article.excerpt}</p>

                  <div className="article-tags">
                    {article.tags.slice(0, 3).map(tag => (
                      <span key={tag} className="article-tag">#{tag}</span>
                    ))}
                  </div>

                  <div className="article-footer">
                    <div className="article-stats">
                      <span className="article-views">👁️ {article.views}</span>
                    </div>
                    <Link to={`/actualites/${article.id}`} className="article-read-more">
                      Lire la suite →
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="pagination">
              <button
                className="pagination-btn"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                ← Précédent
              </button>

              <div className="pagination-numbers">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    className={`pagination-number ${currentPage === page ? 'active' : ''}`}
                    onClick={() => setCurrentPage(page)}
                  >
                    {page}
                  </button>
                ))}
              </div>

              <button
                className="pagination-btn"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Suivant →
              </button>
            </div>
          )}

          {/* Loading state */}
          {loading && (
            <div className="loading-state">
              <div className="loading-spinner"></div>
              <p>Chargement des articles...</p>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default RessourcesActualites;
